---
title: About the Project
description: About Doctrine Site — purpose, scope, and bilingual documentation approach.
---

# About the Project

---

## Purpose

This project exists to provide structured technical documentation in a clear, accessible format. The goal is to create a reference resource that explains specific domains without marketing language or promotional intent.

The site prioritizes precision over persuasion, and explanation over advocacy.

**Non-claims:** This site does not provide certification, compliance assessment, or professional advice. For explicit scope boundaries, see [Scope & Non-Claims](/en/scope/).

---

## Why Bilingual

Content is provided in both English and Ukrainian to serve a broader audience and ensure accessibility across language boundaries.

---

## Current Scope

**Available now:**

- Site structure and navigation
- Method outline
- Boundaries definition
- Contact information

**Coming later:**

- Doctrine materials
- Case studies
- Expanded documentation
